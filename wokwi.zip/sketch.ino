/*
  OFFICE LAYOUT SIMULATION — ESP32 (Wokwi)
  -----------------------------------------
  3 Rooms, each with 2 Fans + 3 Lights:
    - Drawing Room
    - Work Room 1
    - Work Room 2

  Each fan/light is represented by an LED (ON = active).
  Control is done through a built-in WiFi web dashboard
  hosted directly on the ESP32 (works in Wokwi's simulated WiFi).

  Open the Wokwi "Web Browser" / Serial Monitor after boot,
  grab the printed IP address, and open it in the built-in browser.
*/

#include <WiFi.h>
#include <WebServer.h>

// ---------- WiFi (Wokwi simulated network) ----------
const char* ssid     = "Wokwi-GUEST";
const char* password = "";

WebServer server(80);

// ---------- Pin mapping ----------
// Drawing Room
#define DR_LIGHT1 2
#define DR_LIGHT2 4
#define DR_LIGHT3 5
#define DR_FAN1   18
#define DR_FAN2   19

// Work Room 1
#define WR1_LIGHT1 21
#define WR1_LIGHT2 22
#define WR1_LIGHT3 23
#define WR1_FAN1   25
#define WR1_FAN2   26

// Work Room 2
#define WR2_LIGHT1 27
#define WR2_LIGHT2 14
#define WR2_LIGHT3 12
#define WR2_FAN1   13
#define WR2_FAN2   15

struct Device {
  const char* room;
  const char* name;
  int pin;
  bool state;
};

Device devices[] = {
  {"Drawing Room", "Light 1", DR_LIGHT1, false},
  {"Drawing Room", "Light 2", DR_LIGHT2, false},
  {"Drawing Room", "Light 3", DR_LIGHT3, false},
  {"Drawing Room", "Fan 1",   DR_FAN1,   false},
  {"Drawing Room", "Fan 2",   DR_FAN2,   false},

  {"Work Room 1", "Light 1", WR1_LIGHT1, false},
  {"Work Room 1", "Light 2", WR1_LIGHT2, false},
  {"Work Room 1", "Light 3", WR1_LIGHT3, false},
  {"Work Room 1", "Fan 1",   WR1_FAN1,   false},
  {"Work Room 1", "Fan 2",   WR1_FAN2,   false},

  {"Work Room 2", "Light 1", WR2_LIGHT1, false},
  {"Work Room 2", "Light 2", WR2_LIGHT2, false},
  {"Work Room 2", "Light 3", WR2_LIGHT3, false},
  {"Work Room 2", "Fan 1",   WR2_FAN1,   false},
  {"Work Room 2", "Fan 2",   WR2_FAN2,   false},
};

const int deviceCount = sizeof(devices) / sizeof(devices[0]);

// ---------- Web page ----------
String buildPage() {
  String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<title>Office Control Panel</title><style>";
  html += "body{font-family:Arial,sans-serif;background:#f2f2f2;margin:0;padding:20px;}";
  html += "h1{text-align:center;color:#333;}";
  html += ".room{background:#fff;border-radius:10px;padding:15px 20px;margin:15px auto;max-width:480px;box-shadow:0 2px 6px rgba(0,0,0,0.15);}";
  html += ".room h2{margin-top:0;color:#555;border-bottom:2px solid #eee;padding-bottom:8px;}";
  html += ".row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;}";
  html += ".btn{padding:6px 16px;border:none;border-radius:20px;cursor:pointer;font-weight:bold;color:#fff;}";
  html += ".on{background:#2ecc71;} .off{background:#e74c3c;}";
  html += "a{text-decoration:none;}";
  html += "</style></head><body>";
  html += "<h1>Office Layout Control Panel</h1>";

  const char* currentRoom = "";
  for (int i = 0; i < deviceCount; i++) {
    if (String(currentRoom) != String(devices[i].room)) {
      if (i != 0) html += "</div>";
      html += "<div class='room'><h2>" + String(devices[i].room) + "</h2>";
      currentRoom = devices[i].room;
    }
    html += "<div class='row'><span>" + String(devices[i].name) + "</span>";
    html += "<a href='/toggle?id=" + String(i) + "'><button class='btn " + String(devices[i].state ? "on" : "off") + "'>";
    html += devices[i].state ? "ON" : "OFF";
    html += "</button></a></div>";
  }
  html += "</div>";
  html += "<p style='text-align:center;color:#888;'>ESP32 Office Simulation — Wokwi</p>";
  html += "</body></html>";
  return html;
}

void handleRoot() {
  server.send(200, "text/html", buildPage());
}

void handleToggle() {
  if (server.hasArg("id")) {
    int id = server.arg("id").toInt();
    if (id >= 0 && id < deviceCount) {
      devices[id].state = !devices[id].state;
      digitalWrite(devices[id].pin, devices[id].state ? HIGH : LOW);
    }
  }
  server.sendHeader("Location", "/");
  server.send(303);
}

void setup() {
  Serial.begin(115200);

  for (int i = 0; i < deviceCount; i++) {
    pinMode(devices[i].pin, OUTPUT);
    digitalWrite(devices[i].pin, LOW);
  }

  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("Connected! Open this address in the browser: http://");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.on("/toggle", handleToggle);
  server.begin();
}

void loop() {
  server.handleClient();
}